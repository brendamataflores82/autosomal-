#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Slice this string."""
"""WILL"""
>>>robimson
WILL_ROBINSON = 'Danger Will Robinson!'
KLANOX
