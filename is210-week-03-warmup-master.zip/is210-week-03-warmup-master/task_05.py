#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Splinter would be proud."""


TEENAGE_MUTANT_NINJAS = ('Michaelangelo. Leonardo. Rafael. Donatello. Heroes '
                         'in a half shell.')
