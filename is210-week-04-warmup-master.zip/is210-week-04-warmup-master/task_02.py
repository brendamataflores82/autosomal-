#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""This module does some pretty crazy math."""


import hamlet
